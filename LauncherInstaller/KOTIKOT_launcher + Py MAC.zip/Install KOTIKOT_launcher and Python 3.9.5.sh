#!/bin/sh
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install wget
brew install python
path="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
pathfile="${path}/Install-KOTIKOT_launcher.py"
cmd="wget -O ${pathfile} https://raw.githubusercontent.com/BarsTiger/KOTIKOTapps_download_repo/master/LauncherInstaller/Install-KOTIKOT_launcher.py"
$cmd
cd "${path}"
python3 Install-KOTIKOT_launcher.py